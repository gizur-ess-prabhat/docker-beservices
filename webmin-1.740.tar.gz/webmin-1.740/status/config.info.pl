index_status=Stan pokazywany na li�cie,1,1-Stan bie��cy,0-Z&nbsp;ostatniego regularnrgo sprawdzenia
ping_cmd=Polecenie do pingowania hosta,3,Brak
